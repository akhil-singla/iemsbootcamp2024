# -*- coding: utf-8 -*-
"""
Created on Mon May 13 17:46:19 2019

@author: merve
"""

from gurobipy import *

# We need two constraints, one cutting off the top
# left corner and one cutting off the top right corner, e.g.
# (0,2) +---+---+ (2,2)
#       |xx/ \xx|
#       |x/   \x|
#       |/     \|
#       +       +
#       |       |
#       |       |
#       |       |
# (0,0) +---+---+ (2,0)
    
# Create a new Gurobi model
m = Model("CallbackModel")
# Define our variables to be inside a box, and integer
x = m.addVars(range(2), vtype=GRB.INTEGER, lb = 0, ub = 2, name="x")

m.setObjective(x[1], GRB.MAXIMIZE)

iteration = 0

def mycallback(model, where):
    global iteration
    if where == GRB.Callback.MIPSOL:
        iteration += 1
        x_val = model.cbGetSolution(model._vars)
        print("Solution at iteration ",iteration," is (",x_val[0],",",x_val[1],").")
        
        # Allow for some impreciseness in the solution
        TOL = 1e-6
    
        # Check top left, allowing some tolerance
        if x_val[1] - x_val[0] > 1 + TOL:
            # Cut off this solution
            print("Solution was in top left, cut it off")
            # Use the original variables when adding lazy constraint
            model.cbLazy( x[1] - x[0] <= 1)
        # Check top right
        elif x_val[1] + x_val[0] > 3 + TOL:
            # Cut off this solution
            print("Solution was in top right, cut it off")
            # Use the original variables when adding lazy constraint
            model.cbLazy(x[1] + x[0] <= 3)
m._vars = x
m.Params.lazyConstraints = 1
m.optimize(mycallback)

# Print the optimal solution if found
if m.status == GRB.Status.OPTIMAL:
    x_opt = m.getAttr('x', x)
    print("Optimal solution is (",x_opt[0],",",x_opt[1],").")
else:
    print("Optimal solution is not found.")
    
