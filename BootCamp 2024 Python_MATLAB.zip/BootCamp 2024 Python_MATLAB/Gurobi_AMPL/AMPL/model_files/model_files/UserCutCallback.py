# -*- coding: utf-8 -*-
"""
Created on Mon May 13 17:46:19 2019

@author: merve
"""

from gurobipy import *

# We have box constraints and two additional constraints. The top corner is optimal
# for the LP relaxation but fractional, so we should cut off that solution, e.g.
#        (1.5,3)
# (0,3) +---+---+ (3,3)
#       |xx/x\xx|
#       |-/---\-|
#       |/     \|
# (0,0) +---+---+ (3,0)
    
# Create a new Gurobi model
m = Model("CallbackModel")
# Define our variables to be inside a box, and integer
x = m.addVars(range(2), vtype=GRB.INTEGER, lb = 0, ub = 3, name="x")

m.setObjective(x[1], GRB.MAXIMIZE)

m.addConstr(2*x[0] - x[1] >= 0)
m.addConstr(2*x[0] + x[1] <= 6)

iteration = 0
# Create user cut callback function
def mycallback(model, where):
    global iteration
    if where == GRB.Callback.MIPNODE:
        iteration += 1
        x_val = model.cbGetNodeRel(model._vars) # get LP relaxation solution
        print("Solution at iteration ",iteration," is (",x_val[0],",",x_val[1],").")
        
        # Allow for some impreciseness in the solution
        TOL = 1e-6    
        # Check top point, allowing some tolerance
        if x_val[1] > 2.0 + TOL:
            # Cut off this solution
            print("Fractional solution was at top, cut it off")
            # Use the original variables when adding user cut
            model.cbCut( x[1]  <= 2)
m._vars = x
m.Params.Presolve = 0 # not necessary
m.optimize(mycallback)

# Print the optimal solution if found
if m.status == GRB.Status.OPTIMAL:
    x_opt = m.getAttr('x', x)
    print("Optimal solution is (",x_opt[0],",",x_opt[1],").")
else:
    print("Optimal solution is not found.")
    
