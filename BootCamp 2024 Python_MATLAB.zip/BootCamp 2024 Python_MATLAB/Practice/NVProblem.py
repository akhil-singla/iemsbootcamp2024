# -*- coding: utf-8 -*-
"""
Created on Thu Sep  5 12:14:28 2019

@author: mesca
"""

import numpy as np
import scipy.stats as sc
import matplotlib.pyplot as plt 

#Data
cost=2.5
sellPrice=3
salPrice=0.5 

#Function to calculate the profits given an inventory level and the demand
def profitCalculation(inventory, demand):
    profits=sellPrice*np.min([inventory,demand])-cost*inventory+np.max([0,inventory-demand])*salPrice
    return profits

#Create inventory array with different levels of inventory 
inventory_levels=np.arange(0,30,0.25)
#Create list to save final results 
inventory_profit=[]
#Create a loop for each inventory level
for i in range(len(inventory_levels)):
    #Create list to save de profit in each iterations
    preliminary_results=[]
    #Create loop for the 100 iterations
    for j in range(100):
        demand=sc.poisson.rvs(20)
        preliminary_results.append(profitCalculation(inventory_levels[i],demand))
    #Once the 100 iterations are done we save the average profit for the inventory level
    inventory_profit.append(np.mean(preliminary_results))

#Create figure 
fig1=plt.figure(1)
#We plot the variables
plt.plot(inventory_levels,inventory_profit,'r.',label="Poisson" )
plt.xlabel("Inventory")
plt.ylabel("Profit")

#Same exercise but with normal distribution for the demand-------------------------
#Create list to save final results 
inventory_profit_normal=[]
#Create a loop for each inventory level
for i in range(len(inventory_levels)):
    #Create list to save de profit in each iterations
    preliminary_results=[]
    #Create loop for the 100 iterations
    for j in range(100):
        demand=sc.norm.rvs(20,10)
        preliminary_results.append(profitCalculation(inventory_levels[i],demand))
    #Once the 100 iterations are done we save the average profit for the inventory level
    inventory_profit_normal.append(np.mean(preliminary_results))

#Create figure 
fig1=plt.figure(2)
#We plot the variables
plt.plot(inventory_levels,inventory_profit_normal,'r.',label="Normal" )
plt.xlabel("Inventory")
plt.ylabel("Profit")
