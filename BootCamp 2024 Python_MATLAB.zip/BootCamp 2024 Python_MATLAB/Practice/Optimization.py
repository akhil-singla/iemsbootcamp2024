# -*- coding: utf-8 -*-
"""
Created on Thu Sep  5 19:21:18 2019
@author: mesca
"""

import numpy as np

#Create a class for the function with two methods for the objective value and the gradient
class function:
    def __init__(self,a=100):
        self._a=a
        
    def value(self,x):
        a=self._a

        val=a*(x[1]-x[0]**2)**2+(1-x[0])**2
        return val
    
    def grad(self,x):
        grad=np.zeros(2)
        grad[0]=-400*x[0]*(x[1]-x[0]**2)-2*(1-x[0])
        grad[1]=200*(x[1]-x[0]**2)
        return grad

#Method to find the minimum of the function
def minimizeObj(x0,objFunc):
    #Define initial parameters
    iter_count=0
    tol=1e-6
    x_k=np.copy(x0)
    #Call the object's value and gradient
    f_k=objFunc.value(x_k)
    grad_k=objFunc.grad(x_k)
    
    #find norm of the gradient for stopping criteria
    norm=np.linalg.norm(grad_k,np.inf)
    p_k=0
    
    #Print information of the iteration
    print('%6s %10s %13s %11s %11s' %('iter', 'f', 'norm', 'x_1', 'x_2'))
    print('%6i %14.5e %12.4e %11.4e %11.4e' %(iter_count, f_k, norm, x_k[0],x_k[1]))
    
    #First loop: iterates until the norm of the gradient is less than a tolerance level (slope is zero)
    while 1:
        if norm<=tol:
            break
        p_k=np.array(grad_k)*-1
        xtrial=x_k+p_k
        ftrial=objFunc.value(xtrial)
        alpha=1
        
        #Second loop: Guarantees that the next point has a lower objective function (objective function is decreasing)        
        while 1:
            #If the objective function of the new point is greater than the actual objective, it decrease alpha by half. 
            if ftrial>f_k:
                alpha=alpha*0.5
                xtrial=x_k+alpha*p_k
                ftrial=objFunc.value(xtrial)
            else:
                break
        
        #Update information
        f_k=objFunc.value(xtrial)
        x_k=np.copy(xtrial)
        grad_k=objFunc.grad(x_k)
        norm=np.linalg.norm(grad_k,np.inf)
        
        iter_count+=1
        
        # Print the output header every 50 iterations
        if iter_count % 50 == 0:
            print('%6s %10s %13s %11s %11s' %('iter', 'f', 'norm', 'x_1', 'x_2'))
                
        print('%6i %14.5e %12.4e %11.4e %11.4e' %(iter_count, f_k, norm, x_k[0],x_k[1]))
        
        
x0=np.array([-1.2,1])
minimizeObj(x0,function())

    
        
        
    