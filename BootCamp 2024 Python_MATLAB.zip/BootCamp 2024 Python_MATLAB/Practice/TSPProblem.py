# -*- coding: utf-8 -*-
"""
Created on Thu Sep  5 15:04:33 2019

@author: mesca
"""

import numpy as np
import scipy as sc
import pandas

df_RAW = pandas.read_excel('TX_Distances_BC.xlsx') 
df_distances=df_RAW[['ID X', 'ID Y', 'Distance Meters']]
df_distances.columns=['IDx','IDy','Distance']
nodes=list(df_distances['IDx'].drop_duplicates())

#Create variable to save current node
current='DFW'
#Create list for route and add initial node
Route=[]
Route.append(current)

#Add the following nodes
for i in range (len(nodes)-1):
    #Create a data frame with the current node in the x column 
    df_current=df_distances[df_distances['IDx']==current]
    #Reset the index from 0 to the number of cities
    df_current=df_current.reset_index(drop=True)
    insert=0
    
    #Find the next node to insert
    while insert==0:
        #Looks for the closest cities to the current one and convert it to a list and take the first position 
        candidate=df_current.loc[[np.argmin(df_current['Distance'])]]['IDy'].tolist()[0]
        
        #Check if it is already in the list
        #np.sum(np.array()==x) counts the number of elements in the array that are equal to x
        Flag=np.sum(np.array(Route)==candidate)
        #If the node is not in the list, add it and change the current node
        if Flag==0:
            Route.append(candidate)
            insert=1
            current=candidate
        else:
            #Drop the candidate from the list
            df_current=df_current[df_current['IDy']!=candidate]

#Calculates the cost for a route       
def routeCost(route):
    cost=0
    for i in range(len(route)-1):
        cost+=df_distances.loc[(df_distances['IDx']==route[i+1])&(df_distances['IDy']==route[i]),'Distance'].values[0]
    cost+=df_distances.loc[(df_distances['IDx']==route[0])&(df_distances['IDy']==route[len(route)-1]),'Distance'].values[0]  
    return cost

#Calculate cost and print results
cost=routeCost(Route)
print('My route is:',Route, 'and the cost is ', cost)
print('and the cost is: ',cost)


